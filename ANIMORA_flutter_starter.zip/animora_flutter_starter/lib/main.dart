
import 'package:flutter/material.dart';

void main() => runApp(const AnimoraApp());

class AnimoraApp extends StatelessWidget {
  const AnimoraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'ANIMORA',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF070914),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF7C4DFF),
          brightness: Brightness.dark,
        ),
        fontFamily: 'Arial',
        useMaterial3: true,
      ),
      home: const Shell(),
    );
  }
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int index = 0;
  final pages = const [HomePage(), AnimePage(), MangaPage(), FavoritesPage(), ProfilePage()];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => setState(() => index = i),
        backgroundColor: const Color(0xFF0B0D1A),
        indicatorColor: const Color(0xFF2A1A55),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.play_circle_outline), selectedIcon: Icon(Icons.play_circle), label: 'الأنمي'),
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'المانجا'),
          NavigationDestination(icon: Icon(Icons.favorite_border), selectedIcon: Icon(Icons.favorite), label: 'المفضلة'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'حسابي'),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: CustomScrollView(slivers: [
        const SliverAppBar(
          pinned: true, backgroundColor: Color(0xFF070914),
          title: Text('ANIMORA', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.5)),
          actions: [Icon(Icons.search), SizedBox(width: 18), Icon(Icons.notifications_none), SizedBox(width: 12)],
        ),
        SliverPadding(
          padding: const EdgeInsets.all(16),
          sliver: SliverList(delegate: SliverChildListDelegate([
            const SearchBox(),
            const SizedBox(height: 18),
            HeroCard(),
            SectionTitle('🔥 الأكثر مشاهدة'),
            AnimeRow(),
            SectionTitle('🆕 أضيف حديثاً'),
            AnimeRow(),
            SectionTitle('📺 أكمل المشاهدة'),
            AnimeRow(),
          ])),
        ),
      ]),
    );
  }
}

class SearchBox extends StatelessWidget {
  const SearchBox({super.key});
  @override Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 16),
    decoration: BoxDecoration(color: const Color(0xFF101426), borderRadius: BorderRadius.circular(16)),
    child: const TextField(
      decoration: InputDecoration(border: InputBorder.none, icon: Icon(Icons.search), hintText: 'ابحث عن أنمي أو مانجا...'),
    ),
  );
}

class HeroCard extends StatelessWidget {
  const HeroCard({super.key});
  @override Widget build(BuildContext context) => Container(
    height: 220,
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(24),
      gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
        colors: [Color(0xFF28135F), Color(0xFF11162C)]),
    ),
    padding: const EdgeInsets.all(22),
    child: const Align(
      alignment: Alignment.bottomRight,
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('One Piece', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
        SizedBox(height: 6),
        Text('حلقة جديدة متاحة الآن', style: TextStyle(color: Colors.white70)),
        SizedBox(height: 14),
        FilledButton.icon(onPressed: null, icon: Icon(Icons.play_arrow), label: Text('مشاهدة الآن')),
      ]),
    ),
  );
}

class SectionTitle extends StatelessWidget {
  final String text;
  const SectionTitle(this.text, {super.key});
  @override Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(top: 24, bottom: 12),
    child: Text(text, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
  );
}

class AnimeRow extends StatelessWidget {
  const AnimeRow({super.key});
  @override Widget build(BuildContext context) => SizedBox(
    height: 190,
    child: ListView.separated(
      scrollDirection: Axis.horizontal,
      itemCount: 6,
      separatorBuilder: (_, __) => const SizedBox(width: 12),
      itemBuilder: (_, i) => Container(
        width: 125,
        decoration: BoxDecoration(color: const Color(0xFF101426), borderRadius: BorderRadius.circular(16)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(child: Container(
            decoration: BoxDecoration(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
              gradient: LinearGradient(colors: [Colors.deepPurple.shade900, const Color(0xFF11162C)]),
            ),
            child: const Center(child: Icon(Icons.movie, size: 42, color: Colors.white38)),
          )),
          Padding(padding: const EdgeInsets.all(9), child: Text(
            ['One Piece','Naruto','Solo Leveling','Jujutsu','Demon Slayer','Attack on Titan'][i],
            maxLines: 1, overflow: TextOverflow.ellipsis,
          )),
        ]),
      ),
    ),
  );
}

class AnimePage extends StatelessWidget {
  const AnimePage({super.key});
  @override Widget build(BuildContext context) => const CatalogPage(title: 'الأنمي', icon: Icons.play_circle);
}
class MangaPage extends StatelessWidget {
  const MangaPage({super.key});
  @override Widget build(BuildContext context) => const CatalogPage(title: 'المانجا', icon: Icons.menu_book);
}
class CatalogPage extends StatelessWidget {
  final String title; final IconData icon;
  const CatalogPage({required this.title, required this.icon, super.key});
  @override Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(title: Text(title), actions: const [Padding(padding: EdgeInsets.all(12), child: Icon(Icons.search))]),
      body: ListView.separated(
        padding: const EdgeInsets.all(16), itemCount: 10,
        separatorBuilder: (_, __) => const SizedBox(height: 12),
        itemBuilder: (_, i) => ListTile(
          tileColor: const Color(0xFF101426),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          leading: Container(width: 54, height: 70, decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            gradient: const LinearGradient(colors: [Color(0xFF5225A8), Color(0xFF11162C)]),
          )),
          title: Text(['One Piece','Naruto Shippuden','Attack on Titan','Jujutsu Kaisen','Solo Leveling'][i % 5]),
          subtitle: const Text('مستمر • ⭐ 8.7'),
          trailing: Icon(icon),
        ),
      ),
    ),
  );
}

class FavoritesPage extends StatelessWidget {
  const FavoritesPage({super.key});
  @override Widget build(BuildContext context) => const CatalogPage(title: 'المفضلة', icon: Icons.favorite);
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(title: const Text('حسابي')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const CircleAvatar(radius: 42, child: Icon(Icons.person, size: 42)),
        const SizedBox(height: 12),
        const Center(child: Text('ANIMORA User', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
        const SizedBox(height: 24),
        Card(child: ListTile(leading: const Icon(Icons.workspace_premium), title: const Text('Premium'), subtitle: const Text('اشترك بدون إعلانات ومزايا إضافية'), trailing: const Icon(Icons.chevron_left))),
        const Card(child: ListTile(leading: Icon(Icons.history), title: Text('سجل المشاهدة'))),
        const Card(child: ListTile(leading: Icon(Icons.notifications_none), title: Text('الإشعارات'))),
        const Card(child: ListTile(leading: Icon(Icons.settings_outlined), title: Text('الإعدادات'))),
      ]),
    ),
  );
}
