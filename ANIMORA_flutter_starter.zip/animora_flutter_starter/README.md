# ANIMORA Flutter UI Starter

## التشغيل
1. ثبّت Flutter.
2. أنشئ مشروع Flutter أو فك هذا المشروع.
3. شغّل:
   flutter pub get
   flutter run

## ما هو موجود
- Dark Anime UI موحّد
- Bottom navigation
- Home
- Anime catalog
- Manga catalog
- Favorites
- Profile
- RTL Arabic UI
- مكوّنات قابلة للتوسع

## المرحلة التالية
ربط API وقاعدة البيانات، المصادقة، صور المحتوى المرخّص، مشغل الفيديو، قارئ المانجا، الإشعارات والاشتراكات.
